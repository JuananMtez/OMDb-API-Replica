import boto3


    
def lambda_handler(event, context):
    DDB = boto3.resource('dynamodb', region_name='eu-west-3')

    table = DDB.Table('Requests')

    response = table.scan()
    data = response['Items']
    while response.get('LastEvaluatedKey'):
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        data.extend(response['Items'])
    print(data)

#print(lambda_handler({}, None))




   

