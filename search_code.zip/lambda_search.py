import boto3, json
import requests 
import uuid


    
def lambda_handler(event, context):
    response_api = requests.get("https://www.omdbapi.com/?apikey={}&s={}&t={}&y={}&page={}".format(event["apikey"], event["s"], event["t"], event["y"], event["page"]))
    DDB = boto3.client('dynamodb', region_name='eu-west-3')
    
    response_db = DDB.put_item(
        TableName='Requests',
        Item={
            'id': {
                'S': str(uuid.uuid4())
            },
            's': {
                'S': event["s"]
            },
            't': {
                'S': event["t"]
            },
            'y': {
                'S': event["y"]
            },
            'page': {
                'S': event["page"]
            }
            
        }
    )
    

    return response_api.json()

#print(lambda_handler({"s": "Harry", "apikey": "56ef5305", "t":"", "y": "", "page": ""}, None))




   

